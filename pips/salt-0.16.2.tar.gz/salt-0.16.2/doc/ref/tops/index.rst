
.. _salt-top:

===========
Master Tops
===========

Salt includes a number of built-in subsystems to generate top file data, they
are listed listed at
:ref:`all-salt.tops`.

The source for the built-in Salt master tops can be found here:
:blob:`salt/tops`
