.. _all-salt.tops:

========================================
Full list of builtin master tops modules
========================================

.. currentmodule:: salt.tops

.. autosummary::
    :toctree:
    :template: autosummary.rst.tmpl

    ext_nodes
    cobbler
    mongo
