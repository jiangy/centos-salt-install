=======================
salt.modules.bsd_shadow
=======================

.. automodule:: salt.modules.bsd_shadow
    :members: