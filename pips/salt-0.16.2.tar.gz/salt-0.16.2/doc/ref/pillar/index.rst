
.. _salt-pillars:

=======
Pillars
=======

Salt includes a number of built-in external pillars, listed at
:ref:`all-salt.pillars`.

You may also wish to look at the standard pillar documentation, at
:ref:`pillar-configuration`

The source for the built-in Salt pillars can be found here:
:blob:`salt/pillar`
