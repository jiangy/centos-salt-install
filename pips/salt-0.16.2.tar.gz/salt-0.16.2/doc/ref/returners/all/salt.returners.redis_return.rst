===========================
salt.returners.redis_return
===========================

.. automodule:: salt.returners.redis_return
    :members: