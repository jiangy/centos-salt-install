'''
The local returner is used to test the returner interface, it just prints the
return data to the console to verify that it is being passed properly
'''


def returner(ret):
    '''
    Print the return data to the terminal to verify functionality
    '''
    print(ret)
