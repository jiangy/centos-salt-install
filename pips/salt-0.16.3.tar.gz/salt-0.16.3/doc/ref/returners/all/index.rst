.. _all-salt.returners:

=====================================
Full list of builtin returner modules
=====================================

.. currentmodule:: salt.returners

.. autosummary::
    :toctree:
    :template: autosummary.rst.tmpl

    carbon_return
    cassandra_return
    local
    mongo_future_return
    mongo_return
    mysql
    postgres
    redis_return
    sentry_return
    smtp_return
    syslog_return
