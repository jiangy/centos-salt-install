=======================
salt.returners.postgres
=======================

.. automodule:: salt.returners.postgres
    :members: