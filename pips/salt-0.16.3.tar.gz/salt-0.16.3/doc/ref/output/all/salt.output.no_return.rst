=====================
salt.output.no_return
=====================

.. automodule:: salt.output.no_return
    :members: