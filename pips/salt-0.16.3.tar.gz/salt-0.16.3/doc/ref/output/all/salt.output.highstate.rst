=====================
salt.output.highstate
=====================

.. automodule:: salt.output.highstate
    :members: