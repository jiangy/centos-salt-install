.. _client-apis:

==========================
Salt client API interfaces
==========================

.. autoclass:: salt.client.LocalClient
    :members: cmd

.. autoclass:: salt.runner.RunnerClient
    :members: low

.. autoclass:: salt.wheel.Wheel
    :members: master_call
