==================
salt.modules.extfs
==================

.. automodule:: salt.modules.extfs
    :members: