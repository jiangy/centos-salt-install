==================
salt.modules.pkgin
==================

.. automodule:: salt.modules.pkgin
    :members: