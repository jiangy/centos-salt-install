=================
salt.modules.virt
=================

.. automodule:: salt.modules.virt
    :members: