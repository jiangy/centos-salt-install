=======================
salt.modules.solarispkg
=======================

.. automodule:: salt.modules.solarispkg
    :members:
    :exclude-members: available_version
