====================
salt.pillar.cmd_json
====================

.. automodule:: salt.pillar.cmd_json
    :members: